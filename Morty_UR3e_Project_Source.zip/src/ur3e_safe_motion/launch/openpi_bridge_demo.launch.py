from launch import LaunchDescription
from launch.actions import TimerAction
from launch_ros.actions import Node


def generate_launch_description():
    receiver = Node(
        package="ur3e_safe_motion",
        executable="openpi_action_receiver.py",
        output="screen",
    )
    sample_publisher = Node(
        package="ur3e_safe_motion",
        executable="openpi_sample_publisher.py",
        output="screen",
    )
    return LaunchDescription([
        receiver,
        # Start after the receiver so the single sample is not lost at startup.
        TimerAction(period=1.0, actions=[sample_publisher]),
    ])
